USE MicrocontrollersKitsAndParts
SET IDENTITY_INSERT Buyer ON

/***/


INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (1, 'Eric', 'Dee', 'edee@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (2, 'Aaron', 'B.', 'aaronb@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (3, 'Beth', 'C.', 'bethc@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (4, 'Cassy', 'D.', 'cassyd@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (5, 'Dillon', 'E.', 'dillone@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (6, 'Frank', 'G.', 'frankg@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (7, 'Ginna', 'H.', 'ginah@students.ntc.edu')
GO

INSERT INTO Buyer
(BuyerNumber, BuyerFirst, BuyerLast, BuyerEmail)
VALUES (8, 'Harry', 'I.', 'harryi@students.ntc.edu')
GO

 /***/

 SET IDENTITY_INSERT Buyer OFF