﻿USE MicrocontrollersKitsAndParts
SET IDENTITY_INSERT Sale ON

/***/

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (1, 1, 1)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (2, 1, 2)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (3, 1, 3)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (4, 1, 4)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (5, 1, 5)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (6, 1, 6)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (7, 1, 7)
Go

INSERT INTO Sale
(ItemNumber, BuyerNumber, SaleNumber)
VALUES (8, 1, 8)
Go

/***/

SET IDENTITY_INSERT Sale Off