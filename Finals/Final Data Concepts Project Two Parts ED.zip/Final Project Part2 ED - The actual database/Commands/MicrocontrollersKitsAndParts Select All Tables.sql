USE MicrocontrollersKitsAndParts
SELECT * FROM Buyer
SELECT * FROM Manufacturer
SELECT * FROM Part
SELECT * FROM Component
SELECT * FROM Item
SELECT * FROM Kit
SELECT * FROM Sale GO